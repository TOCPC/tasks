#!/usr/bin/env bash
#   *** 1 ***
rm -f 1/01.a
rm -f 1/02.a
rm -f 1/03
rm -f 1/03.a
rm -f 1/04
rm -f 1/04.a
rm -f 1/05
rm -f 1/05.a
rm -f 1/06
rm -f 1/06.a
rm -f 1/07
rm -f 1/07.a
rm -f 1/08
rm -f 1/08.a
rm -f 1/09
rm -f 1/09.a
rm -f 1/10
rm -f 1/10.a
rm -f 1/11
rm -f 1/11.a
rm -f 1/12
rm -f 1/12.a
rm -f 1/13
rm -f 1/13.a
rm -f 1/14.a
rm -f 1/15.a
rm -f 1/16
rm -f 1/16.a
rm -f 1/17.a
rm -f 1/18.a
rm -f 1/19.a
rm -f 1/20.a
rm -f 1/21
rm -f 1/21.a
rm -f 1/22
rm -f 1/22.a
rm -f 1/23
rm -f 1/23.a
rm -f 1/24
rm -f 1/24.a
rm -f 1/25
rm -f 1/25.a
rm -f 1/26
rm -f 1/26.a
rm -f 1/27
rm -f 1/27.a
rm -f 1/28
rm -f 1/28.a
rm -f 1/29
rm -f 1/29.a
rm -f 1/30.a

#   *** tests ***
rm -f tests/01.a

