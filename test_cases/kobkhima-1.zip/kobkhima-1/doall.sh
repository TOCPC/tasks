#!/usr/bin/env bash
#   *** validation ***
scripts/run-validator-tests.sh
scripts/run-checker-tests.sh

#    *** 1 ***
mkdir -p 1
echo "Generating test #3"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 3" "1/03" 3
echo "Generating test #4"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 4" "1/04" 4
echo "Generating test #5"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 5" "1/05" 5
echo "Generating test #6"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 6" "1/06" 6
echo "Generating test #7"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 7" "1/07" 7
echo "Generating test #8"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 8" "1/08" 8
echo "Generating test #9"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 9" "1/09" 9
echo "Generating test #10"
scripts/gen-input-via-stdout.sh "wine files/gen.exe 10" "1/10" 10
echo "Generating test #11"
scripts/gen-input-via-stdout.sh "wine files/gen2.exe 11" "1/11" 11
echo "Generating test #12"
scripts/gen-input-via-stdout.sh "wine files/gen2.exe 12" "1/12" 12
echo "Generating test #13"
scripts/gen-input-via-stdout.sh "wine files/gen2.exe 13" "1/13" 13
echo "Generating test #16"
scripts/gen-input-via-stdout.sh "wine files/gen4.exe 16" "1/16" 16
echo "Generating test #21"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 21" "1/21" 21
echo "Generating test #22"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 22" "1/22" 22
echo "Generating test #23"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 23" "1/23" 23
echo "Generating test #24"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 25" "1/24" 24
echo "Generating test #25"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 26" "1/25" 25
echo "Generating test #26"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 27" "1/26" 26
echo "Generating test #27"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 28" "1/27" 27
echo "Generating test #28"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 29" "1/28" 28
echo "Generating test #29"
scripts/gen-input-via-stdout.sh "wine files/gen3.exe 30" "1/29" 29
echo ""
echo "Generating answer for test #1"
scripts/gen-answer.sh 1/01 1/01.a "1" ""
echo ""
echo "Generating answer for test #2"
scripts/gen-answer.sh 1/02 1/02.a "1" ""
echo ""
echo "Generating answer for test #3"
scripts/gen-answer.sh 1/03 1/03.a "1" ""
echo ""
echo "Generating answer for test #4"
scripts/gen-answer.sh 1/04 1/04.a "1" ""
echo ""
echo "Generating answer for test #5"
scripts/gen-answer.sh 1/05 1/05.a "1" ""
echo ""
echo "Generating answer for test #6"
scripts/gen-answer.sh 1/06 1/06.a "1" ""
echo ""
echo "Generating answer for test #7"
scripts/gen-answer.sh 1/07 1/07.a "1" ""
echo ""
echo "Generating answer for test #8"
scripts/gen-answer.sh 1/08 1/08.a "1" ""
echo ""
echo "Generating answer for test #9"
scripts/gen-answer.sh 1/09 1/09.a "1" ""
echo ""
echo "Generating answer for test #10"
scripts/gen-answer.sh 1/10 1/10.a "1" ""
echo ""
echo "Generating answer for test #11"
scripts/gen-answer.sh 1/11 1/11.a "1" ""
echo ""
echo "Generating answer for test #12"
scripts/gen-answer.sh 1/12 1/12.a "1" ""
echo ""
echo "Generating answer for test #13"
scripts/gen-answer.sh 1/13 1/13.a "1" ""
echo ""
echo "Generating answer for test #14"
scripts/gen-answer.sh 1/14 1/14.a "1" ""
echo ""
echo "Generating answer for test #15"
scripts/gen-answer.sh 1/15 1/15.a "1" ""
echo ""
echo "Generating answer for test #16"
scripts/gen-answer.sh 1/16 1/16.a "1" ""
echo ""
echo "Generating answer for test #17"
scripts/gen-answer.sh 1/17 1/17.a "1" ""
echo ""
echo "Generating answer for test #18"
scripts/gen-answer.sh 1/18 1/18.a "1" ""
echo ""
echo "Generating answer for test #19"
scripts/gen-answer.sh 1/19 1/19.a "1" ""
echo ""
echo "Generating answer for test #20"
scripts/gen-answer.sh 1/20 1/20.a "1" ""
echo ""
echo "Generating answer for test #21"
scripts/gen-answer.sh 1/21 1/21.a "1" ""
echo ""
echo "Generating answer for test #22"
scripts/gen-answer.sh 1/22 1/22.a "1" ""
echo ""
echo "Generating answer for test #23"
scripts/gen-answer.sh 1/23 1/23.a "1" ""
echo ""
echo "Generating answer for test #24"
scripts/gen-answer.sh 1/24 1/24.a "1" ""
echo ""
echo "Generating answer for test #25"
scripts/gen-answer.sh 1/25 1/25.a "1" ""
echo ""
echo "Generating answer for test #26"
scripts/gen-answer.sh 1/26 1/26.a "1" ""
echo ""
echo "Generating answer for test #27"
scripts/gen-answer.sh 1/27 1/27.a "1" ""
echo ""
echo "Generating answer for test #28"
scripts/gen-answer.sh 1/28 1/28.a "1" ""
echo ""
echo "Generating answer for test #29"
scripts/gen-answer.sh 1/29 1/29.a "1" ""
echo ""
echo "Generating answer for test #30"
scripts/gen-answer.sh 1/30 1/30.a "1" ""
echo ""

#    *** tests ***
echo ""
mkdir -p tests
echo "Generating answer for test #1"
scripts/gen-answer.sh tests/01 tests/01.a "tests" ""
echo ""

